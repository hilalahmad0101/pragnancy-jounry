import Dashboard from "@/components/Dashboard";
import Navbar from "@/components/Navbar";
import Sidebar from "@/components/Sidebar";
import React, { useState } from "react";

const Home = () => {
  
  return (
    
        <Dashboard />
  );
};

export default Home;
