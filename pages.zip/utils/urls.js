export const mainUrl = "https://preg-api.medicdn.com";
export const loginUrl = `${mainUrl}/login/`;
export const getAllBlogCategoryUrl = `${mainUrl}/blog_category/api/v1/all/`;
export const getCreateBlogCategoryUrl = `${mainUrl}/blog_category/api/v1/create`;
export const getDeleteBlogCategoryUrl = `${mainUrl}/blog_category/api/v1/delete`;
export const getIdBlogCategoryUrl = `${mainUrl}/blog_category/api/v1/get_one`;
export const getUpdateBlogCategoryUrl = `${mainUrl}/blog_category/api/v1/update`;