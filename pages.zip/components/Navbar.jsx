import React from 'react'

const Navbar = ({showAndHideDropdown, showSidebar,dropdown}) => {
  return (
    <div className="py-4 flex lg:justify-end justify-between px-10 items-center">
    <svg
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      strokeWidth={1.5}
      stroke="currentColor"
      className="w-6 h-6 lg:hidden block cursor-pointer"
      onClick={showSidebar}
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M3.75 6.75h16.5M3.75 12h16.5M12 17.25h8.25"
      />
    </svg>

    <ul>
      <li className="flex items-center relative">
        <img
          src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dXNlcnN8ZW58MHx8MHx8&auto=format&fit=crop&w=400&q=60"
          alt=""
          className="w-10 rounded-full"
        />
        <h1 className="text-[16px] font-normal ml-5">Hilal Ahmad</h1>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={1.5}
          stroke="currentColor"
          className="w-5 h-5 ml-3 cursor-pointer"
          onClick={showAndHideDropdown}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M19.5 8.25l-7.5 7.5-7.5-7.5"
          />
        </svg>

        <div
          className={`w-full absolute bg-white top-14 shadow-md rounded-sm ${
            !dropdown ? "hidden" : ""
          }`}
        >
          <ul className="py-2 px-4">
            <li className="flex items-center my-2 hover:bg-pink-400 py-1 px-1 hover:py-1 hover:px-1 rounded-md cursor-pointer hover:text-white">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-6 h-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z"
                />
              </svg>
              <h2 className="ml-2">Update Profile</h2>
            </li>
            <li className="flex items-center my-2 hover:bg-pink-400 py-1 px-1 hover:py-1 hover:px-1 rounded-md cursor-pointer hover:text-white">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-6 h-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z"
                />
              </svg>

              <h2 className="ml-2">Password</h2>
            </li>
            <li className="flex items-center my-2 hover:bg-pink-400 py-1 px-1 hover:py-1 hover:px-1 rounded-md cursor-pointer hover:text-white">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-6 h-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75"
                />
              </svg>

              <h2 className="ml-2">Logout</h2>
            </li>
          </ul>
        </div>
      </li>
    </ul>
  </div>
  )
}

export default Navbar